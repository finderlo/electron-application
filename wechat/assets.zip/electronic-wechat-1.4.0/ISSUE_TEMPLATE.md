#### Description



#### Specifications

- Version of Electron (run `$ electron --version`): `v0.0.0`
- OS: `<OS>`
- Stack trace from the error message (if any)

``` 
<Stack trace here>
```
